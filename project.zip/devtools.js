/* Asks the emulator's Chrome a question about the page that is open (through adb's devtools socket).
   node devtools.js <url-part> '<js expression>'   — prints the answer as JSON */
const WebSocket = require('ws');
(async () => {
  const [part, expr] = process.argv.slice(2);
  let target;
  for (let i = 0; i < 15 && !target; i++) {
    try {
      const list = await (await fetch('http://127.0.0.1:9222/json')).json();
      target = list.find(t => t.type === 'page' && t.url.includes(part) && t.webSocketDebuggerUrl);
      if (!target && i === 14) console.log('PAGES: ' + list.map(t => t.type + ' ' + t.url).join(' | '));
    } catch (e) { if (i === 14) console.log('NO DEVTOOLS: ' + e.message); }
    if (!target) await new Promise(r => setTimeout(r, 1000));
  }
  if (!target) { console.log('NO PAGE matching ' + part); process.exit(0); }
  const ws = new WebSocket(target.webSocketDebuggerUrl);
  await new Promise((r, j) => { ws.on('open', r); ws.on('error', j); });
  ws.send(JSON.stringify({ id: 1, method: 'Runtime.evaluate', params: { expression: expr, awaitPromise: true, returnByValue: true } }));
  ws.on('message', m => { const d = JSON.parse(m); if (d.id === 1) { console.log('ANSWER ' + part + ': ' + JSON.stringify(d.result && d.result.result && d.result.result.value !== undefined ? d.result.result.value : d)); ws.close(); process.exit(0); } });
  setTimeout(() => { console.log('TIMEOUT'); process.exit(0); }, 15000);
})();
