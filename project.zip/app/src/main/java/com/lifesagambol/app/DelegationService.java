package com.lifesagambol.app;

import com.google.androidbrowserhelper.playbilling.digitalgoods.DigitalGoodsRequestHandler;

/** Lets the site's notifications show as this app's notifications, and (r390) gives the page Google Play
 *  billing — the Digital Goods API — so Skip the Wait is bought through Google Play inside the app. */
public class DelegationService extends com.google.androidbrowserhelper.trusted.DelegationService {
    @Override
    public void onCreate() {
        super.onCreate();
        registerExtraCommandHandler(new DigitalGoodsRequestHandler(getApplicationContext()));
    }
}
