package com.lifesagambol.app;

/** Lets the site's notifications show as this app's notifications. */
public class DelegationService extends com.google.androidbrowserhelper.trusted.DelegationService {
}
