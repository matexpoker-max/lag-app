package com.lifesagambol.app;

/** Opens Lifes a Gambol full screen in the phone's Chrome engine (a Trusted Web Activity). */
public class LauncherActivity extends com.google.androidbrowserhelper.trusted.LauncherActivity {
}
