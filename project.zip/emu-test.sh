#!/bin/bash
# Runs inside the Android emulator job: installs the app, opens pages, saves screenshots and page checks to shots/.
set -x
mkdir -p shots
(cd proj && npm install --no-save --silent ws@8)   # for devtools.js, the page checks
APK=proj/app/build/outputs/apk/debug/app-debug.apk
adb install -r "$APK"
adb shell dumpsys package com.android.chrome | grep -m1 versionName | tee shots/browsers.txt
# A test copy is signed with GitHub's throwaway key, so tell the emulator's Chrome to trust it for one of our sites
# (the Play copy is trusted through the sites' assetlinks files instead) and skip Chrome's welcome screens.
flag(){ adb shell "echo '_ --disable-fre --no-default-browser-check --no-first-run --disable-digital-asset-link-verification-for-url=\"$1\"' > /data/local/tmp/chrome-command-line"; adb shell chmod 644 /data/local/tmp/chrome-command-line; adb shell am force-stop com.android.chrome; adb shell am force-stop com.lifesagambol.app; }
adb shell am set-debug-app --persistent com.android.chrome
flag https://lifesagambol.com
adb logcat -c

shot(){ adb exec-out screencap -p > "shots/$1.png"; echo "shot $1"; }
open(){ adb shell am start -a android.intent.action.VIEW -d "$1" com.lifesagambol.app; }
launch(){ adb shell monkey -p com.lifesagambol.app -c android.intent.category.LAUNCHER 1; }
ask(){ adb forward tcp:9222 localabstract:chrome_devtools_remote >/dev/null; node proj/devtools.js "$1" "$2" | tee -a shots/checks.txt; }
CHECK='(async()=>JSON.stringify({url:location.href, app:document.documentElement.classList.contains("lag-app"), standalone:matchMedia("(display-mode: standalone)").matches, ref:document.referrer, sw:(await navigator.serviceWorker.getRegistrations()).map(r=>r.active&&r.active.scriptURL), title:document.title.slice(0,50)}))()'

launch
sleep 4;  shot 00-launch
sleep 26; shot 01-home
ask lifesagambol.com/ "$CHECK"
adb shell input swipe 540 1800 540 600 400; sleep 3; shot 02-home-scrolled
open "https://lifesagambol.com/games"; sleep 15; shot 03-games
ask lifesagambol.com/games "$CHECK"

# the games site, trusted the same way
flag https://games.lifesagambol.com
open "https://games.lifesagambol.com/"; sleep 25; shot 04-poker-room
ask games.lifesagambol.com "$CHECK"

# no connection: the games site (its offline worker was just installed above)
adb shell svc wifi disable; adb shell svc data disable; sleep 3
adb shell am force-stop com.android.chrome; adb shell am force-stop com.lifesagambol.app
open "https://games.lifesagambol.com/spades"; sleep 15; shot 05-offline-games
# no connection: opening the app itself
flag https://lifesagambol.com
adb shell svc wifi disable; adb shell svc data disable
launch; sleep 15; shot 06-offline-launch
adb shell svc wifi enable; adb shell svc data enable; sleep 12; shot 07-back-online
adb shell input keyevent KEYCODE_HOME; sleep 1
adb shell am start -a android.intent.action.MAIN -c android.intent.category.HOME >/dev/null; sleep 2; shot 08-home-screen
# the app drawer (the home screen's bottom row can draw a 'suggested app' ring round an icon — the drawer shows the icon as it is)
adb shell input keyevent 284; sleep 3; shot 09-app-drawer
adb logcat -d > shots/logcat-full.txt
grep -i -E 'TrustedWebActivity|androidbrowserhelper|TwaLauncher|LauncherActivity|lifesagambol' shots/logcat-full.txt | head -300 > shots/logcat-twa.txt
cat shots/checks.txt
ls -la shots
