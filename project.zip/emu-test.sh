#!/bin/bash
# Runs inside the Android emulator job: installs the app, opens pages, saves screenshots to shots/.
set -x
mkdir -p shots
APK=proj/app/build/outputs/apk/debug/app-debug.apk
adb install -r "$APK"
adb shell pm list packages | grep -i -E 'chrome|webview' | tee shots/browsers.txt
adb shell dumpsys package com.android.chrome | grep -m1 versionName | tee -a shots/browsers.txt
# A test copy is signed with GitHub's throwaway key, so tell the emulator's Chrome to trust it for our two sites
# (the real Play copy is trusted through the site's assetlinks file instead) and skip Chrome's welcome screens.
adb shell "echo '_ --disable-fre --no-default-browser-check --no-first-run --disable-digital-asset-link-verification-for-url=https://lifesagambol.com,https://games.lifesagambol.com' > /data/local/tmp/chrome-command-line"
adb shell chmod 644 /data/local/tmp/chrome-command-line
adb shell am set-debug-app --persistent com.android.chrome
adb shell am force-stop com.android.chrome
adb shell settings put global window_animation_scale 0
adb logcat -c

shot(){ adb exec-out screencap -p > "shots/$1.png"; echo "shot $1"; }
open(){ adb shell am start -a android.intent.action.VIEW -d "$1" com.lifesagambol.app; }

adb shell monkey -p com.lifesagambol.app -c android.intent.category.LAUNCHER 1
sleep 4;  shot 00-launch
sleep 26; shot 01-home
adb shell input swipe 540 1800 540 600 400; sleep 3; shot 02-home-scrolled
open "https://lifesagambol.com/games"; sleep 20; shot 03-games
open "https://games.lifesagambol.com/"; sleep 25; shot 04-poker-room
# offline
adb shell svc wifi disable; adb shell svc data disable; sleep 3
adb shell am force-stop com.lifesagambol.app
adb shell monkey -p com.lifesagambol.app -c android.intent.category.LAUNCHER 1
sleep 15; shot 05-offline
adb shell svc wifi enable; adb shell svc data enable
adb shell input keyevent KEYCODE_HOME; sleep 2; shot 06-homescreen
adb logcat -d > shots/logcat-full.txt
grep -i -E 'TrustedWebActivity|androidbrowserhelper|TwaLauncher|digital.?asset|verif|LauncherActivity|lifesagambol' shots/logcat-full.txt | head -300 > shots/logcat-twa.txt
ls -la shots
