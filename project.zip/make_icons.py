"""Builds the app icons and the launch-screen picture from the site's logo (512x512 PNG).
   python3 make_icons.py logo.png   (run from the project folder)"""
import sys, os
from PIL import Image

src = Image.open(sys.argv[1]).convert('RGBA')
# the logo file has a see-through margin round the dark-green square — cut it off so the square fills the icon
box = src.getchannel('A').point(lambda a: 255 if a > 200 else 0).getbbox()
if box: src = src.crop(box)
src = src.resize((512, 512), Image.LANCZOS)
res = 'app/src/main/res'

# the colour round the logo's edge, so the round/squircle icon shapes blend into it
px = src.convert('RGB').load(); edge = []
for i in range(0, 512, 8):
    edge += [px[i, 0], px[i, 511], px[0, i], px[511, i]]
bg = tuple(sum(c[k] for c in edge) // len(edge) for k in range(3))
hexbg = '#%02X%02X%02X' % bg
os.makedirs(res + '/values', exist_ok=True)
open(res + '/values/icon_colors.xml', 'w').write(
    '<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <color name="iconBackground">%s</color>\n</resources>\n' % hexbg)

# legacy square icons (phones before Android 8)
for d, s in {'mdpi': 48, 'hdpi': 72, 'xhdpi': 96, 'xxhdpi': 144, 'xxxhdpi': 192}.items():
    os.makedirs('%s/mipmap-%s' % (res, d), exist_ok=True)
    src.resize((s, s), Image.LANCZOS).save('%s/mipmap-%s/ic_launcher.png' % (res, d), optimize=True)

# adaptive icon foreground: 108dp canvas, the logo at 84dp so the circle mask keeps the banner
for d, s in {'mdpi': 108, 'hdpi': 162, 'xhdpi': 216, 'xxhdpi': 324, 'xxxhdpi': 432}.items():
    canvas = Image.new('RGBA', (s, s), bg + (255,))
    inner = round(s * 84 / 108)
    canvas.paste(src.resize((inner, inner), Image.LANCZOS), ((s - inner) // 2, (s - inner) // 2))
    canvas.save('%s/mipmap-%s/ic_launcher_foreground.png' % (res, d), optimize=True)

# launch screen picture
os.makedirs(res + '/drawable-nodpi', exist_ok=True)
src.resize((384, 384), Image.LANCZOS).save(res + '/drawable-nodpi/splash.png', optimize=True)

# the Play Store listing icon (512x512, no transparency)
os.makedirs('store', exist_ok=True)
src.convert('RGB').save('store/icon-512.png')
print('icons done, edge colour', hexbg)
