#!/bin/bash
# Runs on the GitHub Mac after the build: the app on a virtual iPhone, a photograph of each page, and what each page
# said about itself (the app writes lag-checks.txt when it is started with -lagCheck 1).
set -x
APP=$(find ios/build/Build/Products/Debug-iphonesimulator -maxdepth 1 -name "*.app" | head -1)
mkdir -p ishots
xcrun simctl boot "$UDID" || true
xcrun simctl bootstatus "$UDID" -b
xcrun simctl status_bar "$UDID" override --time 9:41 --batteryState charged --batteryLevel 100 --cellularBars 4 --wifiBars 3 || true
xcrun simctl install "$UDID" "$APP"
xcrun simctl listapps "$UDID" | grep -A3 com.lifesagambol.app | head -8
run(){
  local name=$1 url=$2 wait=${3:-25}
  xcrun simctl terminate "$UDID" com.lifesagambol.app 2>/dev/null || true
  if [ -n "$url" ]; then xcrun simctl launch "$UDID" com.lifesagambol.app -lagCheck 1 -lagStart "$url"
  else xcrun simctl launch "$UDID" com.lifesagambol.app -lagCheck 1; fi
  sleep "$wait"
  xcrun simctl io "$UDID" screenshot "ishots/$name.png"
}
run 00-launch "" 2
run 01-home "" 25
run 02-games https://lifesagambol.com/games
run 03-shop https://lifesagambol.com/shop
run 04-poker-room https://games.lifesagambol.com/ 30
run 05-blackjack https://games.lifesagambol.com/blackjack
run 06-giveback-opens-in-safari https://lifesagambol.com/giveback 12
DATA=$(xcrun simctl get_app_container "$UDID" com.lifesagambol.app data)
cp "$DATA/Documents/lag-checks.txt" ishots/checks.txt 2>/dev/null || echo "no checks file was written" > ishots/checks.txt
cat ishots/checks.txt
ls -la ishots
