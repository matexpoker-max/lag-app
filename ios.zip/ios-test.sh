#!/bin/bash
# Runs on the GitHub Mac after the build: the app on a virtual iPhone, a photograph of each page, and what each page
# said about itself (the app writes lag-checks.txt when it is started with -lagCheck 1).
set -x
APP=$(find ios/build/Build/Products/Debug-iphonesimulator -maxdepth 1 -name "*.app" | head -1)
mkdir -p ishots
# Booting the virtual iPhone has hung for 15+ minutes once (bootstatus never returned). macOS has no `timeout`, so the
# wait runs in the background and is given BOOT_SECS; a phone that does not come up is shut down, erased and tried once
# more; a second failure stops this script with a line saying so (the screenshots step still runs).
BOOT_SECS=${BOOT_SECS:-240}
bootwait(){
  xcrun simctl boot "$UDID" 2>/dev/null || true
  xcrun simctl bootstatus "$UDID" -b > /dev/null 2>&1 &
  local pid=$! t=0
  while kill -0 "$pid" 2>/dev/null; do
    if [ "$t" -ge "$BOOT_SECS" ]; then kill "$pid" 2>/dev/null; wait "$pid" 2>/dev/null; echo "boot: not up after ${BOOT_SECS}s"; return 1; fi
    sleep 5; t=$((t+5))
  done
  wait "$pid"; local rc=$?
  [ "$rc" -eq 0 ] && echo "boot: up after ${t}s" || echo "boot: bootstatus answered $rc after ${t}s"
  return $rc
}
if ! bootwait; then
  xcrun simctl shutdown "$UDID" 2>/dev/null || true
  xcrun simctl erase "$UDID" 2>/dev/null || true
  if ! bootwait; then
    mkdir -p ishots; echo "The virtual iPhone did not start in two tries of ${BOOT_SECS}s — nothing was photographed." > ishots/checks.txt
    exit 1
  fi
fi
xcrun simctl status_bar "$UDID" override --time 9:41 --batteryState charged --batteryLevel 100 --cellularBars 4 --wifiBars 3 || true
xcrun simctl install "$UDID" "$APP"
xcrun simctl listapps "$UDID" | grep -A3 com.lifesagambol.app | head -8
run(){
  local name=$1 url=$2 wait=${3:-25}
  xcrun simctl terminate "$UDID" com.lifesagambol.app 2>/dev/null || true
  if [ -n "$url" ]; then xcrun simctl launch "$UDID" com.lifesagambol.app -lagCheck 1 -lagStart "$url"
  else xcrun simctl launch "$UDID" com.lifesagambol.app -lagCheck 1; fi
  sleep "$wait"
  xcrun simctl io "$UDID" screenshot "ishots/$name.png"
}
run 00-launch "" 2
run 01-home "" 25
run 02-games https://lifesagambol.com/games
run 03-shop https://lifesagambol.com/shop
run 04-poker-room https://games.lifesagambol.com/ 30
run 05-blackjack https://games.lifesagambol.com/blackjack
run 06-giveback-opens-in-safari https://lifesagambol.com/giveback 12
DATA=$(xcrun simctl get_app_container "$UDID" com.lifesagambol.app data)
cp "$DATA/Documents/lag-checks.txt" ishots/checks.txt 2>/dev/null || echo "no checks file was written" > ishots/checks.txt
cat ishots/checks.txt
ls -la ishots
