import XCTest
import StoreKitTest
@testable import LAGGames

/// The App Store bridge against Xcode's own test store (Products.storekit): what the page is told for every way a
/// purchase can go, and that a purchase stays with Apple until the page says the server has it.
final class StoreTests: XCTestCase {
    var session: SKTestSession!

    override func setUpWithError() throws {
        session = try SKTestSession(configurationFileNamed: "Products")
        session.resetToDefaultState()
        session.disableDialogs = true
        session.clearTransactions()
    }

    override func tearDownWithError() throws {
        session.clearTransactions()
    }

    private func payload(_ jws: String) -> [String: Any] {
        let parts = jws.split(separator: ".")
        guard parts.count == 3 else { return [:] }
        var s = String(parts[1]).replacingOccurrences(of: "-", with: "+").replacingOccurrences(of: "_", with: "/")
        while s.count % 4 != 0 { s += "=" }
        guard let d = Data(base64Encoded: s), let o = try? JSONSerialization.jsonObject(with: d) as? [String: Any] else { return [:] }
        return o
    }

    @MainActor func testProductsAreListedWithTheirPrice() async {
        let r = await Store.shared.handle("products")
        XCTAssertEqual(r["ok"] as? Bool, true)
        let items = r["items"] as? [[String: Any]] ?? []
        XCTAssertEqual(items.count, 1)
        XCTAssertEqual(items.first?["sku"] as? String, "skip_the_wait")
        XCTAssertEqual(items.first?["price"] as? String, "$1.99")
    }

    @MainActor func testCanPay() async {
        let r = await Store.shared.handle("can")
        XCTAssertEqual(r["ok"] as? Bool, true)
        XCTAssertNotNil(r["canPay"] as? Bool)
    }

    @MainActor func testSomethingNotSoldIsRefused() async {
        let r = await Store.shared.handle("buy", sku: "a_free_lunch", account: UUID().uuidString)
        XCTAssertEqual(r["ok"] as? Bool, false)
        XCTAssertNil(r["jws"])
    }

    @MainActor func testNoAccountNoPurchase() async {
        let r = await Store.shared.handle("buy", sku: "skip_the_wait", account: nil)
        XCTAssertEqual(r["ok"] as? Bool, false)
        let bad = await Store.shared.handle("buy", sku: "skip_the_wait", account: "not-a-uuid")
        XCTAssertEqual(bad["ok"] as? Bool, false)
    }

    @MainActor func testUnknownRequest() async {
        let r = await Store.shared.handle("refund-me")
        XCTAssertEqual(r["ok"] as? Bool, false)
    }

    @MainActor func testAPurchaseCarriesTheAccountAndStaysUntilFinished() async throws {
        let account = UUID()
        let r = await Store.shared.handle("buy", sku: "skip_the_wait", account: account.uuidString)
        XCTAssertEqual(r["ok"] as? Bool, true, "\(r)")
        let jws = try XCTUnwrap(r["jws"] as? String)
        let tid = try XCTUnwrap(r["tid"] as? String)
        let p = payload(jws)
        XCTAssertEqual((p["appAccountToken"] as? String)?.lowercased(), account.uuidString.lowercased())
        XCTAssertEqual(p["productId"] as? String, "skip_the_wait")
        XCTAssertEqual(p["type"] as? String, "Consumable")

        // Not finished yet: Apple still holds it, and it is offered again.
        let held = await Store.shared.handle("unfinished")
        let ids = (held["items"] as? [[String: Any]] ?? []).compactMap { $0["tid"] as? String }
        XCTAssertTrue(ids.contains(tid), "the purchase should be waiting: \(ids)")

        let f = await Store.shared.handle("finish", tid: tid)
        XCTAssertEqual(f["ok"] as? Bool, true)
        let after = await Store.shared.handle("unfinished")
        let ids2 = (after["items"] as? [[String: Any]] ?? []).compactMap { $0["tid"] as? String }
        XCTAssertFalse(ids2.contains(tid), "a finished purchase is not offered again")

        // Finishing twice is harmless.
        let again = await Store.shared.handle("finish", tid: tid)
        XCTAssertEqual(again["ok"] as? Bool, true)
    }

    @MainActor func testAskToBuyIsPending() async {
        session.askToBuyEnabled = true
        let r = await Store.shared.handle("buy", sku: "skip_the_wait", account: UUID().uuidString)
        XCTAssertEqual(r["ok"] as? Bool, false)
        XCTAssertEqual(r["pending"] as? Bool, true)
    }
}
