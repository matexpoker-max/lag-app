import XCTest
@testable import LAGGames

/// Where an address goes: the site stays in the app, donations go to Safari (Apple 3.2.2), everything else too.
final class LinkRulesTests: XCTestCase {
    private func rule(_ s: String, main: Bool = true) -> LinkRule { LinkRules.rule(for: URL(string: s)!, mainFrame: main) }

    func testTheSiteStaysInTheApp() {
        XCTAssertEqual(rule("https://lifesagambol.com/games"), .inApp)
        XCTAssertEqual(rule("https://www.lifesagambol.com/shop"), .inApp)
        XCTAssertEqual(rule("https://games.lifesagambol.com/?table=lisbon"), .inApp)
        XCTAssertEqual(rule("https://LifesAGambol.com/"), .inApp)
    }

    func testDonationsOpenInSafari() {
        XCTAssertEqual(rule("https://lifesagambol.com/giveback"), .safari)
        XCTAssertEqual(rule("https://lifesagambol.com/giveback/"), .safari)
        XCTAssertEqual(rule("https://lifesagambol.com/giveback.html"), .safari)
        XCTAssertEqual(rule("https://lifesagambol.com/unity?x=1"), .safari)
        XCTAssertEqual(rule("https://www.lifesagambol.com/Unity"), .safari)
        XCTAssertEqual(rule("https://lifesagambol.com/unityfoo"), .inApp, "only the page itself, not a name that starts the same")
        XCTAssertEqual(rule("https://games.lifesagambol.com/giveback"), .safari)
    }

    func testOtherSitesOpenInSafari() {
        XCTAssertEqual(rule("https://www.youtube.com/watch?v=1"), .safari)
        XCTAssertEqual(rule("https://evil-lifesagambol.com/"), .safari)
        XCTAssertEqual(rule("https://lifesagambol.com.evil.net/"), .safari)
    }

    func testCheckoutAndSignInHelpersStay() {
        XCTAssertEqual(rule("https://www.paypal.com/checkoutnow?token=1"), .inApp)
        XCTAssertEqual(rule("https://lifesagambol.firebaseapp.com/__/auth/handler"), .inApp)
        XCTAssertEqual(rule("https://notpaypal.com/"), .safari)
    }

    func testFramesLoadWhereTheyAre() {
        XCTAssertEqual(rule("https://www.youtube.com/embed/x", main: false), .inApp)
        XCTAssertEqual(rule("https://lifesagambol.com/giveback", main: false), .inApp)
    }

    func testThePhoneHandlesItsOwn() {
        XCTAssertEqual(rule("mailto:lucky@lifesagambol.com"), .system)
        XCTAssertEqual(rule("tel:5551234"), .system)
        XCTAssertEqual(rule("https://apps.apple.com/app/id1"), .system)
    }

    func testOddSchemes() {
        XCTAssertEqual(rule("about:blank"), .inApp)
        XCTAssertEqual(rule("data:text/html,hi"), .block)
        XCTAssertEqual(rule("javascript:alert(1)"), .block)
    }
}
