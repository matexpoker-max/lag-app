import UIKit
import AVFoundation

@main
final class AppDelegate: UIResponder, UIApplicationDelegate {
    var window: UIWindow?

    func application(_ application: UIApplication,
                     didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        // The games' sounds play whatever the ringer switch says; only the game's own mute silences them
        // (Lucky, r340). Mixed with the player's music rather than stopping it.
        try? AVAudioSession.sharedInstance().setCategory(.playback, mode: .default, options: [.mixWithOthers])

        var start = AppConfig.startURL
        // A test run may open another page (`-lagStart https://lifesagambol.com/games`) — the site's own pages only.
        if let s = UserDefaults.standard.string(forKey: "lagStart"), let u = URL(string: s), LinkRules.isHome(u) {
            start = u
        }
        let w = UIWindow(frame: UIScreen.main.bounds)
        w.backgroundColor = AppConfig.ground
        w.rootViewController = WebViewController(start: start)
        w.makeKeyAndVisible()
        window = w
        Store.shared.start()
        return true
    }
}
