import UIKit
import WebKit

/// A page's new window, as a sheet over the page that opened it (which keeps running underneath — a table stays a
/// table). Done closes it; a page that closes itself (window.close) closes it too.
final class PopupViewController: UIViewController, WKNavigationDelegate, WKUIDelegate {
    let webView: WKWebView

    init(configuration: WKWebViewConfiguration) {
        webView = WKWebView(frame: .zero, configuration: configuration)
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder: NSCoder) { fatalError("not used") }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = AppConfig.ground
        navigationItem.rightBarButtonItem = UIBarButtonItem(systemItem: .done, primaryAction: UIAction { [weak self] _ in
            self?.dismiss(animated: true)
        })
        let bar = UINavigationBarAppearance()
        bar.configureWithOpaqueBackground()
        bar.backgroundColor = AppConfig.ground
        bar.titleTextAttributes = [.foregroundColor: UIColor.white]
        navigationController?.navigationBar.standardAppearance = bar
        navigationController?.navigationBar.scrollEdgeAppearance = bar
        navigationController?.navigationBar.tintColor = UIColor(red: 0.96, green: 0.84, blue: 0.48, alpha: 1)
        webView.navigationDelegate = self
        webView.uiDelegate = self
        webView.isOpaque = false
        webView.backgroundColor = AppConfig.ground
        #if DEBUG
        if #available(iOS 16.4, *) { webView.isInspectable = true }
        #endif
        webView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(webView)
        let g = view.safeAreaLayoutGuide
        NSLayoutConstraint.activate([
            webView.topAnchor.constraint(equalTo: g.topAnchor),
            webView.bottomAnchor.constraint(equalTo: g.bottomAnchor),
            webView.leadingAnchor.constraint(equalTo: g.leadingAnchor),
            webView.trailingAnchor.constraint(equalTo: g.trailingAnchor),
        ])
    }

    func webView(_ webView: WKWebView, decidePolicyFor action: WKNavigationAction,
                 decisionHandler: @escaping @MainActor @Sendable (WKNavigationActionPolicy) -> Void) {
        guard let url = action.request.url else { decisionHandler(.cancel); return }
        let main = action.targetFrame?.isMainFrame ?? true
        switch LinkRules.rule(for: url, mainFrame: main) {
        case .inApp: decisionHandler(.allow)
        case .block: decisionHandler(.cancel)
        case .safari, .system:
            decisionHandler(.cancel)
            UIApplication.shared.open(url)
            // A window that was only ever a way out to Safari has nothing left to show.
            if webView.url == nil || webView.url?.scheme == "about" { dismiss(animated: true) }
        }
    }

    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        title = webView.title
    }

    func webViewDidClose(_ webView: WKWebView) {
        dismiss(animated: true)
    }

    func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration,
                 for action: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
        // A window from a window: load it here rather than stack sheets.
        if let url = action.request.url {
            switch LinkRules.rule(for: url, mainFrame: true) {
            case .inApp: webView.load(action.request)
            case .block: break
            case .safari, .system: UIApplication.shared.open(url)
            }
        }
        return nil
    }

    func webView(_ webView: WKWebView, runJavaScriptAlertPanelWithMessage message: String,
                 initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping @MainActor @Sendable () -> Void) {
        Dialogs.alert(on: self, message: message) { completionHandler() }
    }

    func webView(_ webView: WKWebView, runJavaScriptConfirmPanelWithMessage message: String,
                 initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping @MainActor @Sendable (Bool) -> Void) {
        Dialogs.confirm(on: self, message: message) { completionHandler($0) }
    }
}
