import UIKit

/// Lifes a Gambol's iPhone app — the site, full screen, with the parts only an app can do (the App Store's own
/// purchase for Skip the Wait, sounds that play with the ringer off). Everything the site does, it does on the site.
enum AppConfig {
    /// Where the app opens. `?app=ios` tells the page it is inside the app on the very first load
    /// (after that the user agent says so on every page).
    static let startURL = URL(string: "https://lifesagambol.com/?app=ios")!

    /// Added to the browser's own user agent on every request, so every page knows it is the app.
    static let userAgentTag = "LAGApp-iOS/1"

    /// The site's own addresses — they open inside the app.
    static let homeHosts: Set<String> = ["lifesagambol.com", "www.lifesagambol.com", "games.lifesagambol.com"]

    /// Other addresses a page may need to open inside the app: sign-in helpers and the checkout for the shop's
    /// physical merchandise (Apple allows a physical product to be paid for outside the App Store).
    static let helperHostSuffixes = ["firebaseapp.com", "paypal.com", "paypalobjects.com"]

    /// Pages that collect donations. Apple's rule (3.2.2) is that a donation is made on the website in Safari,
    /// never inside the app — so these always open in Safari. Lucky, 5 Oct 2026: "yes you can open those in the
    /// phones browser".
    static let browserPaths = ["/giveback", "/unity"]

    /// The site's own colour behind the page and the status bar (the icon's ground).
    static let ground = UIColor(red: 0x1A / 255.0, green: 0x2E / 255.0, blue: 0x1A / 255.0, alpha: 1)

    /// The App Store products the page may ask for.
    static let products: Set<String> = ["skip_the_wait"]
}

/// What happens to an address the page wants to open. Pure, so it can be tested on its own.
enum LinkRule: Equatable {
    case inApp          // load it here
    case safari         // hand it to Safari
    case system         // tel:, mailto:, sms:, the App Store — the phone opens it
    case block          // a scheme with nothing to do as a whole page (data:, blob:, an unknown scheme)
}

enum LinkRules {
    static func isHome(_ url: URL) -> Bool {
        guard let h = url.host?.lowercased() else { return false }
        return AppConfig.homeHosts.contains(h)
    }

    static func isHelper(_ url: URL) -> Bool {
        guard let h = url.host?.lowercased() else { return false }
        return AppConfig.helperHostSuffixes.contains { h == $0 || h.hasSuffix("." + $0) }
    }

    /// A donation page on the site.
    static func isDonation(_ url: URL) -> Bool {
        guard isHome(url) else { return false }
        var p = url.path.lowercased()
        if p.hasSuffix(".html") { p = String(p.dropLast(5)) }
        while p.count > 1 && p.hasSuffix("/") { p.removeLast() }
        return AppConfig.browserPaths.contains { p == $0 || p.hasPrefix($0 + "/") }
    }

    /// `mainFrame`: whether the address would replace the whole page (an embedded frame — a video, the checkout's
    /// own button — always loads where it is).
    static func rule(for url: URL, mainFrame: Bool) -> LinkRule {
        let scheme = (url.scheme ?? "").lowercased()
        switch scheme {
        case "http", "https":
            break
        case "tel", "mailto", "sms", "itms-apps", "itms-appss", "facetime":
            return .system
        case "about":
            return .inApp       // a new window starts on about:blank before the checkout sends it somewhere
        case "data", "blob":
            return mainFrame ? .block : .inApp
        default:
            return mainFrame ? .block : .inApp
        }
        if !mainFrame { return .inApp }
        if isDonation(url) { return .safari }
        if url.host?.lowercased() == "apps.apple.com" { return .system }
        if isHome(url) || isHelper(url) { return .inApp }
        return .safari
    }
}
