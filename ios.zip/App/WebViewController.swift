import UIKit
import WebKit

/// The site, full screen. One web view for the whole visit; a page that opens a new window (a table's link that must
/// not take the player away from their hand, the checkout's own window) gets a sheet over it, so the page underneath
/// keeps running exactly as a second tab would.
final class WebViewController: UIViewController, WKNavigationDelegate, WKUIDelegate {
    let webView: WKWebView
    private let start: URL
    private let offline = OfflineView()
    private var lastGood: URL?
    private var checks = 0

    init(start: URL) {
        self.start = start
        webView = WKWebView(frame: .zero, configuration: WebViewController.makeConfiguration())
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder: NSCoder) { fatalError("not used") }

    static func makeConfiguration() -> WKWebViewConfiguration {
        let c = WKWebViewConfiguration()
        c.websiteDataStore = .default()                     // stay signed in between visits
        c.allowsInlineMediaPlayback = true
        c.mediaTypesRequiringUserActionForPlayback = []
        c.preferences.javaScriptCanOpenWindowsAutomatically = true
        c.applicationNameForUserAgent = "Version/17.0 Mobile/15E148 Safari/604.1 " + AppConfig.userAgentTag
        c.userContentController.addScriptMessageHandler(Store.shared, contentWorld: .page, name: "lagStore")
        return c
    }

    override var preferredStatusBarStyle: UIStatusBarStyle { .lightContent }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = AppConfig.ground
        webView.isOpaque = false
        webView.backgroundColor = AppConfig.ground
        webView.scrollView.backgroundColor = AppConfig.ground
        webView.scrollView.contentInsetAdjustmentBehavior = .never
        webView.allowsBackForwardNavigationGestures = true
        webView.navigationDelegate = self
        webView.uiDelegate = self
        #if DEBUG
        if #available(iOS 16.4, *) { webView.isInspectable = true }
        #endif
        webView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(webView)
        let g = view.safeAreaLayoutGuide
        NSLayoutConstraint.activate([
            webView.topAnchor.constraint(equalTo: g.topAnchor),
            webView.bottomAnchor.constraint(equalTo: g.bottomAnchor),
            webView.leadingAnchor.constraint(equalTo: g.leadingAnchor),
            webView.trailingAnchor.constraint(equalTo: g.trailingAnchor),
        ])
        offline.translatesAutoresizingMaskIntoConstraints = false
        offline.isHidden = true
        offline.onRetry = { [weak self] in self?.retry() }
        view.addSubview(offline)
        NSLayoutConstraint.activate([
            offline.topAnchor.constraint(equalTo: view.topAnchor),
            offline.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            offline.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            offline.trailingAnchor.constraint(equalTo: view.trailingAnchor),
        ])
        Store.shared.webView = webView
        webView.load(URLRequest(url: start))
    }

    private func retry() {
        offline.isHidden = true
        webView.load(URLRequest(url: lastGood ?? start))
    }

    // MARK: where an address goes

    func webView(_ webView: WKWebView, decidePolicyFor action: WKNavigationAction,
                 decisionHandler: @escaping @MainActor @Sendable (WKNavigationActionPolicy) -> Void) {
        guard let url = action.request.url else { decisionHandler(.cancel); return }
        let main = action.targetFrame?.isMainFrame ?? true
        switch LinkRules.rule(for: url, mainFrame: main) {
        case .inApp: decisionHandler(.allow)
        case .block: decisionHandler(.cancel)
        case .safari, .system:
            decisionHandler(.cancel)
            UIApplication.shared.open(url)
        }
    }

    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        offline.isHidden = true
        if let u = webView.url, LinkRules.isHome(u) { lastGood = u }
        runCheck()
    }

    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
        failed(error)
    }

    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
        failed(error)
    }

    private func failed(_ error: Error) {
        let e = error as NSError
        if e.domain == NSURLErrorDomain && e.code == NSURLErrorCancelled { return }
        if e.domain == "WebKitErrorDomain" && e.code == 102 { return }   // a link handed to Safari
        if e.domain == NSURLErrorDomain {
            offline.show(e.code == NSURLErrorNotConnectedToInternet || e.code == NSURLErrorNetworkConnectionLost
                ? "No connection" : "The site did not answer")
        }
    }

    /// iOS can stop a page's process when memory is short; bring the page back rather than leave a blank screen.
    func webViewWebContentProcessDidTerminate(_ webView: WKWebView) {
        webView.reload()
    }

    // MARK: new windows, and the page's own questions

    func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration,
                 for action: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
        if let url = action.request.url, url.absoluteString != "", url.scheme != "about" {
            switch LinkRules.rule(for: url, mainFrame: true) {
            case .inApp: break
            case .block: return nil
            case .safari, .system:
                UIApplication.shared.open(url)
                return nil
            }
        }
        let sheet = PopupViewController(configuration: configuration)
        let nav = UINavigationController(rootViewController: sheet)
        nav.modalPresentationStyle = .pageSheet
        topMost().present(nav, animated: true)
        return sheet.webView
    }

    private func topMost() -> UIViewController {
        var c: UIViewController = self
        while let p = c.presentedViewController { c = p }
        return c
    }

    func webView(_ webView: WKWebView, runJavaScriptAlertPanelWithMessage message: String,
                 initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping @MainActor @Sendable () -> Void) {
        Dialogs.alert(on: topMost(), message: message) { completionHandler() }
    }

    func webView(_ webView: WKWebView, runJavaScriptConfirmPanelWithMessage message: String,
                 initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping @MainActor @Sendable (Bool) -> Void) {
        Dialogs.confirm(on: topMost(), message: message) { completionHandler($0) }
    }

    func webView(_ webView: WKWebView, runJavaScriptTextInputPanelWithPrompt prompt: String, defaultText: String?,
                 initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping @MainActor @Sendable (String?) -> Void) {
        Dialogs.prompt(on: topMost(), message: prompt, text: defaultText) { completionHandler($0) }
    }

    // MARK: the checks a test run asks for (`-lagCheck 1`): what the page says about itself, written to a file

    private func runCheck() {
        guard UserDefaults.standard.bool(forKey: "lagCheck") else { return }
        checks += 1
        let n = checks
        let js = """
        const o = { url: location.href, title: document.title.slice(0, 60),
          ua: navigator.userAgent.indexOf('LAGApp-iOS') >= 0, app: window.LAG_APP || null,
          appClass: document.documentElement.classList.contains('lag-app'),
          bridge: !!(window.webkit && webkit.messageHandlers && webkit.messageHandlers.lagStore),
          text: (document.body ? document.body.innerText.length : 0) };
        try { o.can = await webkit.messageHandlers.lagStore.postMessage({ op: 'can' }); } catch (e) { o.can = 'error: ' + e; }
        try { o.bogus = await webkit.messageHandlers.lagStore.postMessage({ op: 'buy', sku: 'not_a_thing', account: '00000000-0000-4000-8000-000000000000' }); } catch (e) { o.bogus = 'error: ' + e; }
        return JSON.stringify(o);
        """
        webView.callAsyncJavaScript(js, arguments: [:], in: nil, in: .page) { result in
            let line: String
            switch result {
            case .success(let v): line = "\(n) \(v)"
            case .failure(let e): line = "\(n) error \(e.localizedDescription)"
            }
            Checks.write(line)
        }
    }
}

enum Checks {
    static func write(_ line: String) {
        guard let dir = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first else { return }
        let f = dir.appendingPathComponent("lag-checks.txt")
        let data = (line + "\n").data(using: .utf8)!
        if let h = try? FileHandle(forWritingTo: f) {
            h.seekToEndOfFile(); h.write(data); try? h.close()
        } else {
            try? data.write(to: f)
        }
    }
}

/// The page's own alert / confirm / prompt — without these a web view silently skips them.
@MainActor
enum Dialogs {
    static func alert(on vc: UIViewController, message: String, done: @escaping () -> Void) {
        let a = UIAlertController(title: nil, message: message, preferredStyle: .alert)
        a.addAction(UIAlertAction(title: "OK", style: .default) { _ in done() })
        vc.present(a, animated: true)
    }

    static func confirm(on vc: UIViewController, message: String, done: @escaping (Bool) -> Void) {
        let a = UIAlertController(title: nil, message: message, preferredStyle: .alert)
        a.addAction(UIAlertAction(title: "Cancel", style: .cancel) { _ in done(false) })
        a.addAction(UIAlertAction(title: "OK", style: .default) { _ in done(true) })
        vc.present(a, animated: true)
    }

    static func prompt(on vc: UIViewController, message: String, text: String?, done: @escaping (String?) -> Void) {
        let a = UIAlertController(title: nil, message: message, preferredStyle: .alert)
        a.addTextField { $0.text = text }
        a.addAction(UIAlertAction(title: "Cancel", style: .cancel) { _ in done(nil) })
        a.addAction(UIAlertAction(title: "OK", style: .default) { [weak a] _ in done(a?.textFields?.first?.text ?? "") })
        vc.present(a, animated: true)
    }
}

/// "No connection" with a way back, instead of an empty white page.
final class OfflineView: UIView {
    var onRetry: (() -> Void)?
    private let title = UILabel()

    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = AppConfig.ground
        let clover = UILabel()
        clover.text = "☘️"
        clover.font = .systemFont(ofSize: 56)
        title.font = .systemFont(ofSize: 22, weight: .bold)
        title.textColor = UIColor(red: 0.96, green: 0.98, blue: 0.96, alpha: 1)
        let line = UILabel()
        line.text = "Check your connection, then try again."
        line.font = .systemFont(ofSize: 16)
        line.textColor = UIColor(red: 0.81, green: 0.89, blue: 0.83, alpha: 1)
        line.numberOfLines = 0
        line.textAlignment = .center
        var cfg = UIButton.Configuration.filled()
        cfg.title = "Try again"
        cfg.baseBackgroundColor = UIColor(red: 0.83, green: 0.69, blue: 0.22, alpha: 1)
        cfg.baseForegroundColor = UIColor(red: 0.07, green: 0.16, blue: 0.10, alpha: 1)
        cfg.cornerStyle = .large
        cfg.contentInsets = NSDirectionalEdgeInsets(top: 12, leading: 28, bottom: 12, trailing: 28)
        let button = UIButton(configuration: cfg, primaryAction: UIAction { [weak self] _ in self?.onRetry?() })
        let stack = UIStackView(arrangedSubviews: [clover, title, line, button])
        stack.axis = .vertical
        stack.alignment = .center
        stack.spacing = 14
        stack.translatesAutoresizingMaskIntoConstraints = false
        addSubview(stack)
        NSLayoutConstraint.activate([
            stack.centerXAnchor.constraint(equalTo: centerXAnchor),
            stack.centerYAnchor.constraint(equalTo: centerYAnchor),
            stack.leadingAnchor.constraint(greaterThanOrEqualTo: leadingAnchor, constant: 24),
            stack.trailingAnchor.constraint(lessThanOrEqualTo: trailingAnchor, constant: -24),
        ])
    }

    required init?(coder: NSCoder) { fatalError("not used") }

    func show(_ text: String) {
        title.text = text
        isHidden = false
    }
}
