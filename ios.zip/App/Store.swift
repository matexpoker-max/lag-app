import Foundation
import StoreKit
import WebKit

/// The App Store, for the page. The page asks through `window.webkit.messageHandlers.lagStore.postMessage({op, ...})`,
/// which answers with a promise. Nothing here decides whether a purchase counts: the page sends what Apple signed
/// (the transaction's JWS) to the games server, which checks Apple's signature and adds the refill ONCE, and only
/// then does the page say `finish` — so a purchase the server never heard about stays with Apple and is sent again
/// the next time the app opens (`unfinished`).
@MainActor
final class Store: NSObject, WKScriptMessageHandlerWithReply {
    static let shared = Store()

    private var products: [String: Product] = [:]
    private var waiting: [UInt64: Transaction] = [:]      // verified, not finished yet
    private var updates: Task<Void, Never>?
    weak var webView: WKWebView?

    /// Purchases that finish while the app is open but not in a `buy` — an "Ask to Buy" a parent approved later,
    /// a purchase interrupted and completed in Settings. They are handed to the page as they arrive.
    func start() {
        guard updates == nil else { return }
        updates = Task.detached { [weak self] in
            for await result in Transaction.updates {
                await self?.arrived(result)
            }
        }
    }

    private func arrived(_ result: VerificationResult<Transaction>) {
        guard case .verified(let tx) = result else { return }
        waiting[tx.id] = tx
        let item: [String: Any] = ["jws": result.jwsRepresentation, "tid": String(tx.id), "sku": tx.productID]
        guard let data = try? JSONSerialization.data(withJSONObject: item),
              let json = String(data: data, encoding: .utf8) else { return }
        webView?.evaluateJavaScript("window.LAGSTORE_update && window.LAGSTORE_update(\(json))", completionHandler: nil)
    }

    // MARK: the page's questions

    func userContentController(_ userContentController: WKUserContentController,
                               didReceive message: WKScriptMessage,
                               replyHandler: @escaping @MainActor @Sendable (Any?, String?) -> Void) {
        // Only the site's own pages may buy anything.
        let host = message.frameInfo.securityOrigin.host.lowercased()
        guard message.frameInfo.isMainFrame, AppConfig.homeHosts.contains(host),
              message.frameInfo.securityOrigin.protocol == "https" else {
            replyHandler(nil, "not allowed here")
            return
        }
        guard let body = message.body as? [String: Any], let op = body["op"] as? String else {
            replyHandler(nil, "bad message")
            return
        }
        let sku = body["sku"] as? String
        let account = body["account"] as? String
        let tid = body["tid"] as? String
        Task { @MainActor in
            let answer = await self.handle(op, sku: sku, account: account, tid: tid)
            replyHandler(answer, nil)
        }
    }

    /// Every answer is a plain dictionary (what a promise in the page can carry). Internal for the tests.
    func handle(_ op: String, sku: String? = nil, account: String? = nil, tid: String? = nil) async -> [String: Any] {
        switch op {
        case "can":
            return ["ok": true, "canPay": AppStore.canMakePayments]
        case "products":
            return await productList()
        case "buy":
            return await buy(sku: sku, account: account)
        case "finish":
            return await finish(tid: tid)
        case "unfinished":
            return await unfinished()
        default:
            return ["ok": false, "err": "unknown request"]
        }
    }

    private func load() async throws {
        let missing = AppConfig.products.subtracting(products.keys)
        if missing.isEmpty { return }
        for p in try await Product.products(for: Array(missing)) { products[p.id] = p }
    }

    private func productList() async -> [String: Any] {
        do { try await load() } catch {
            return ["ok": false, "err": "The App Store did not answer — try again in a moment."]
        }
        let items: [[String: Any]] = products.values.sorted { $0.id < $1.id }.map { p in
            ["sku": p.id, "price": p.displayPrice, "name": p.displayName,
             "value": NSDecimalNumber(decimal: p.price).doubleValue,
             "currency": p.priceFormatStyle.currencyCode]
        }
        return ["ok": true, "items": items]
    }

    private func buy(sku: String?, account: String?) async -> [String: Any] {
        guard let sku = sku, AppConfig.products.contains(sku) else {
            return ["ok": false, "err": "That is not something sold here."]
        }
        // The account the purchase is for: the games server checks it is the account that sends it.
        guard let account = account, let token = UUID(uuidString: account) else {
            return ["ok": false, "err": "Sign in first ☘"]
        }
        guard AppStore.canMakePayments else {
            return ["ok": false, "err": "Purchases are turned off on this iPhone (Screen Time)."]
        }
        do { try await load() } catch {
            return ["ok": false, "err": "The App Store did not answer — try again in a moment."]
        }
        guard let product = products[sku] else {
            return ["ok": false, "err": "Skip the Wait is not on sale in the App Store yet."]
        }
        do {
            let result = try await product.purchase(options: [.appAccountToken(token)])
            switch result {
            case .success(let verification):
                switch verification {
                case .verified(let tx):
                    waiting[tx.id] = tx
                    return ["ok": true, "jws": verification.jwsRepresentation, "tid": String(tx.id), "sku": tx.productID]
                case .unverified(_, _):
                    return ["ok": false, "err": "Apple could not confirm that purchase — nothing has been added."]
                }
            case .userCancelled:
                return ["ok": false, "cancelled": true, "err": "No charge — your free refill is still on the way."]
            case .pending:
                return ["ok": false, "pending": true,
                        "err": "Waiting for approval — your refill lands the moment it is approved."]
            @unknown default:
                return ["ok": false, "err": "The purchase did not go through — nothing was charged."]
            }
        } catch {
            return ["ok": false, "err": "The purchase did not go through — nothing was charged."]
        }
    }

    private func finish(tid: String?) async -> [String: Any] {
        guard let tid = tid, let id = UInt64(tid) else { return ["ok": false, "err": "bad transaction"] }
        if let tx = waiting[id] {
            await tx.finish()
            waiting[id] = nil
            return ["ok": true]
        }
        for await result in Transaction.unfinished {
            if case .verified(let tx) = result, tx.id == id {
                await tx.finish()
                return ["ok": true]
            }
        }
        return ["ok": true, "already": true]
    }

    /// Purchases Apple still holds that the server has not been told about.
    private func unfinished() async -> [String: Any] {
        var items: [[String: Any]] = []
        for await result in Transaction.unfinished {
            guard case .verified(let tx) = result, AppConfig.products.contains(tx.productID),
                  tx.revocationDate == nil else { continue }
            waiting[tx.id] = tx
            items.append(["jws": result.jwsRepresentation, "tid": String(tx.id), "sku": tx.productID])
        }
        return ["ok": true, "items": items]
    }
}
